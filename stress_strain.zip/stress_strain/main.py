from stress_strain.core import calculator as calc
from stress_strain.core.calculator import *
from stress_strain.models.material import Material
import csv

all_computed_stress = []
all_computed_strain = []
num_sessions = 0
session_list = []

while True:
    try:
        print("=" * 100)
        name = input("Enter material name:")
        force = float(input("Enter force (in Newtons):"))
        area = float(input("Enter area (in m^2):"))
        original_leng = float(input("Enter original length (in m):"))
        change_leng = float(input("Enter change in length (in m):"))
        print("=" * 100)

        f = validate_force(force)
        a = validate_area(area)
        ol = validate_original_len(original_leng)
        cl = validate_change_len(change_leng)
        stress = calculate_stress(f,a)
        strain = calculate_strain(cl,ol)

        print(f"{'Stess & Strain Results':^100}")
        print("=" * 100)
        print("Material:",name)
        print("Stress result: ",f"{stress:.3f}","Pa")
        print("Strain result: ",f"{strain:.3f}")
        print("=" * 100)

        all_computed_stress.append(stress)
        all_computed_strain.append(strain)
        num_sessions = num_sessions + 1
        session_dictionary = {"Material": name, "Force":force, "Area":area, "OL":original_leng, "CL":change_leng, "Stress":stress, "Strain":strain}
        session_list.append(session_dictionary)

        add_options = input("Would you like to enhance your results or add other options (yes/no):").lower()
        if add_options == "yes":
            print("=" * 100)
            print(f"{'Enhancements and Other Options':^100}")
            print("=" * 100)
            print("1) Convert stress from Pa to psi")
            print("2) Young Modulus: Compare  Predicted VS Measured Stress")
            print("3) Material Preset Comparison")
            print("=" * 100)
            chosen_option = int(input("Enter your choice (1 to 3):"))
            print("=" * 100)
            if chosen_option == 1:
                Pa_psi = convert_stress(stress)
                print("Material:", name)
                print("Stress result in psi:", f"{Pa_psi:.3f}","psi")
            elif chosen_option == 2:
                E_value = float(input("Enter E-value:"))
                young_mod = calculate_young_modulus(stress,strain)
                print("Material:", name)
                print("Young's Modulus:", f"{young_mod:.3f}","Pa")
                pred_stress = calculate_predicted_stress(E_value,strain)
                print("Predicted stress:", f"{pred_stress:.3f}","Pa")
                print("Measured stress:", f"{stress:.3f}","Pa")
                if pred_stress == stress:
                    print("Conclusion: The material follows Hooke's Law")
                elif pred_stress > stress:
                    print("Conclusion: Material has non-linear yielding")
                else:
                    print("Conclusion: Material softening may occur")
            elif chosen_option == 3:
                mat_pres = Material()
                print(f"{'Material Presets':^100}")
                print("=" * 100)
                mat_pres.display_material_presets()
                print("=" * 100)
                input_mat = input("Enter material name to access equivalent E-value:")
                E_value_mat_preset = mat_pres.access_material_presets(input_mat)
                print("=" * 100)
                pred_stress_preset = calculate_predicted_stress(E_value_mat_preset,strain)
                print("Selected E-value:", E_value_mat_preset,"Pa")
                print("Predicted stress using E-values of material:", f"{pred_stress_preset:.3f}","Pa")
                print("Measured stress:", f"{stress:.3f}","Pa")
                if pred_stress_preset == stress:
                    print("Conclusion: The material follows Hooke's Law")
                elif pred_stress_preset > stress:
                    print("Conclusion: Material has non-linear yielding")
                else:
                    print("Conclusion: Material softening may occur")

        print("=" * 100)
        print(f"{'Summary Sessions':^100}")
        print("=" * 100)
        print("Number of sessions:", num_sessions)
        print("Lowest recorded stress:", f"{min(all_computed_stress):.3f}","Pa")
        print("Highest recorded stress:", f"{max(all_computed_stress):.3f}","Pa")
        print("Lowest recorded strain:", f"{min(all_computed_strain):.3f}")
        print("Highest recorded strain:", f"{max(all_computed_strain):.3f}")
        print("=" * 100)
        save_to_file = input("Would you like to save your calculations (yes/no):").lower()
        if save_to_file == "yes":
            filename = "Stress_Strain_Calculations_Data.csv"
            with open(filename, mode='w', newline='') as file:
                writer = csv.DictWriter(file, fieldnames=session_list[0].keys())
                writer.writeheader()
                writer.writerows(session_list)
            print("Session saved succedfully")
        elif save_to_file == "no":
            print("Session not saved")

        print("=" * 100)
        exit_program = input("Do you want to exit program (yes/no):").lower()
        print("=" * 100)
        if exit_program == "yes":
            break
        elif exit_program == "no":
            continue

    except ValueError:
        print("Invalid input: inputs must be integer/float & area/original length must not be negative.")
        exit_program = input("Do you want to exit program (yes/no):").lower()
        print("=" * 100)
        if exit_program == "yes":
            break
        elif exit_program == "no":
            continue

    except ZeroDivisionError:
        print("Invalid input: inputs for area and original length of material must not be zero.")
        exit_program = input("Do you want to exit program (yes/no):").lower()
        print("=" * 100)
        if exit_program == "yes":
            break
        elif exit_program == "no":
            continue

    except KeyError:
        print("Invalid input: the material that you are trying to input is not in the list of material presets provide.")
        exit_program = input("Do you want to exit program (yes/no):").lower()
        print("=" * 100)
        if exit_program == "yes":
            break
        elif exit_program == "no":
            continue