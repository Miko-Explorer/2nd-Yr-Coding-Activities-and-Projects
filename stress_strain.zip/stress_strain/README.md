**Project Title:**
* Stress Strain Calculator

**Project Description:**
* Summary of what the project does and its purpose:
  * Calculates stress and strain of various materials based from user inputs and provide insights in order
    to help engineers and manufacturers decide what materials to use when crafting or building products
    and services for the masses, and also to know and test material performance in various fields such as 
    material strength, durability, and other factors where materials could experience under extreme conditions
    in order to build and create products and structures that could stand the test of time and also could 
    stand against human and earthly challenges. 

**Features:**
  * Calculates and checks the ff:
    * Error handling:
      * Validates inputted force
      * Validates inputted area
      * Validates inputted original length of material
      * Validates inputted change of length of material after the test
      * Validates inputted material name to access E-value
    * Calculates material stress
    * Calculates material strain
    * Calculates Young's Modulus
    * Converts unit of Stress from 'Pa' (Pascals) to 'psi' (Pressure unit).
    * Predicted Stress is calculated either of the ff:
      * Based from a given material preset.
      * Based from user input.
  * Provides the ff:
    * Computed strain, stress, young's modulus, predicted stress.
    * Compares measured stress to computed predicted stress. 
    * Provides an insight about the measurements results and inputted by the user. 
    * Provide session summary per calculations done. 
    * Enables users to either save their inputs, outputs, and calculations done via CSV file or not.

**Installation:**
* Ensure Python 3.10+ is installed. 
* Clone or download the project folder. 
* Open the folder in your IDE (such as PyCharm or VS Code). 
* Run main.py to start the program.

**Usage:**
* Baseline input and expected outputs:
  * Inputs:
    * Enter material name: Iron
    * Enter force (in newtons): 1000 
    * Enter area (in m^2): 0.01 
    * Enter original length (in m): 0.5 
    * Enter change in length (in m): 0.005
  * Expected Outputs:
    * Material: Iron
    * Strain result: 100000.000 Pa
    * Stress result: 0.010
* Integrated enhancements after the baseline outputs:
  * Inputs:
    * Would you like to enhance your results or add other options (yes/no):yes
      * #After confirming it would show a list of enhancements that you could do and these are the ff:
        1) Convert stress from Pa to psi
        2) Young Modulus: Compare  Predicted VS Measured Stress
        3) Material Preset Comparison
    * Enter your choice (1 to 3): 1
      * #If user chose option 1 this would convert the measured stress from Pa (Pascals) to psi (Pressure).
    * Enter your choice (1 to 3): 2
    * Enter E-value: 200000000
      * #If user chose option 2 and entered an E-value it would compute for the predicted stress and young's modulus.
      * #Compares computed predicted stress (E * strain) to measured stress and provide material insights. 
    * Enter your choice (1 to 3): 3
    * Enter material name to access equivalent E-value: Steel
      * #If user chose option 3 it would display a list of materials along with their corresponding E-values. 
      * #The program would prompt the user to choose what corresponding E-value of material to use. 
      * #Calculates predicted stress from the measured strain and the E-value of the material chosen. 
      * #Compares computed predicted stress (E * strain) to measured stress and provide material insights. 
  * Outputs:
    * Option#1 output:
      * Material: Iron
      * Stress result in psi: 14.504 psi
      * Option#2 output:
        * Material: Iron
        * Young's Modulus: 10000000.000 Pa
        * Predicted stress: 2000000.000 Pa
        * Measured stress: 100000.000 Pa
        * Conclusion: Material has non-linear yielding
      * Option#3 output:
        * Selected E-value: 200000000000.0 Pa
        * Predicted stress using E-values of material: 2000000000.000 Pa
        * Measured stress: 100000.000 Pa
        * Conclusion: Material has non-linear yielding
  * Summary sessions and saving calculation history to CSV file:
    * Outputs of summary sessions:
      * Number of sessions: 1
      * Lowest recorded stress: 100000.000 Pa
      * Highest recorded stress: 100000.000 Pa
      * Lowest recorded strain: 0.010
      * Highest recorded strain: 0.010
    * Inputs for file saving:
      * Would you like to save your calculations (yes/no): yes
        * #If the user typed yes it will save the all inputs and outputs of the user into a CSV file.
        * #If the user typed no it will not save all inputs and outputs of the user into a CSV file. 

**Project Structure:**
* ![img.png](img.png)

**Future Enhancements:**
* Create a more presentable GUI for this application
* If possible the source code for main.py could be improved to better understand the flow of the application. 
* If a file has been created after the first calculation session the preceding sessions could update the 
  CSV file that has been already created in the first place. 
* If possible minimize the number of lines of code present in the main.py or main interface of the application.  
* Integrate other important features such as:
  * Argparse mode
  * OOP Wrapper 
  * Plot and other infographics that can visualize data being inputted or produce. 

**File Logging:**
* Data stored in CSV file are the following:
  * Force, Area, OL (Original Length), CL (Change in Length), Strain, Stress
* The created CSV file containing all basic inputs and outputs of the user is stored in the same directory 
  where your Python files are located, specifically in the folder you designated for your project files.

**Author Information:**
* Name: Enrico Miguel Veloso
* Section: 2DSA2
* Program: BS Data Science and Analytics 
* Year: 2nd YR
* AY: 2024-2028
* Course: Programming for Data Science