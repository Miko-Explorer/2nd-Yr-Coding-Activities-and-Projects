def validate_force(force:float) -> float:
    """Validates input force of user"""
    if type(force) != float:
        raise ValueError
    else:
        return force

def validate_area(area:float) -> float:
    """Validates input area of user"""
    if type(area) != float:
        raise ValueError
    elif area < 0:
        raise ValueError
    elif area == 0:
        raise ZeroDivisionError
    else:
        return area

def validate_original_len(original_leng:float) -> float:
    """Validates input original length of material of user"""
    if type(original_leng) != float:
        raise ValueError
    elif original_leng < 0:
        raise ValueError
    elif original_leng == 0:
        raise ZeroDivisionError
    else:
        return original_leng

def validate_change_len(change_leng:float) -> float:
    """Validates input change in length of material of user"""
    if type(change_leng) != float:
        raise ValueError
    else:
        return change_leng

def calculate_stress(f,a) -> float:
    """Calculates Material Stress"""
    stress = f / a
    return stress

def calculate_strain(cl,ol) -> float:
    """Calculates Material Strain"""
    strain = cl / ol
    return strain

def convert_stress(stress) -> float:
    """Converts unit of Stress Pa (pascals) to psi (pressure)"""
    stress_psi = stress * 0.000145038
    return stress_psi

def calculate_young_modulus(stress,strain) -> float:
    """Calculates Material Young's Modulus"""
    young_modulus = stress / strain
    return young_modulus

def calculate_predicted_stress(E_value,strain) -> float:
    """Calculates Predicted/Theoretical Stress"""
    predicted_stress = E_value * strain
    return predicted_stress

def calculate_difference(stress,predicted_stress) -> float:
    """Calculates difference between Stress and Predicted Stress"""
    difference = stress - predicted_stress
    return difference