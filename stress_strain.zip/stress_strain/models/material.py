class Material:
    def __init__(self):
        """Initialization of material presets in a form of a dictionary where all material presets are stored"""
        self.material_presets = {"Steel":200000000000.000, "Aluminum":69000000000.000,
                                 "Copper":110000000000.000, "Brass":100000000000.000,
                                 "Titanium":116000000000.000, "Glass":70000000000.000,
                                 "Wood":12000000000.000, "Rubber":1000000.000,
                                 "CarbonFiber":2800000000.000, "Concrete":30000000000.000}

    def display_material_presets(self):
        """Displays all material presets and their E-values"""
        for mat_name, mat_ym in self.material_presets.items():
            print(f"*{mat_name} : {mat_ym}")

    def access_material_presets(self, key_mat2:str):
        """Displays and acccess E-value of a specific materila in the material presets"""
        if key_mat2 in self.material_presets:
            return self.material_presets[key_mat2]
        else:
            raise KeyError