create database hogwarts_enrollment_sys_ini;

use hogwarts_enrollment_sys_ini; 

create table registrar(
	REG_ID int(10) zerofill primary key not null, 
    constraint CHK_REG_ID check(1 <= REG_ID <= 9999999999), 
    REG_NAME varchar(100) not null, 
    REG_AGE int not null, 
    constraint CHK_REG_AGE check(18 <= REG_AGE <= 99), 
    REG_GENDER enum("Male", "Female") not null, 
    constraint CHK_REG_GENDER check(REG_GENDER = "Male" 
    or REG_GENDER = "Female")
);

create table payment_method(
	PAY_BANK enum("BDO", "BPI", "Metrobank", 
    "Gcash", "Maya", "QRPH") primary key not null, 
    constraint CHK_PAY_BANK check(PAY_BANK = "BDO" 
    or PAY_BANK = "BPI"
    or PAY_BANK = "Gcash" 
    or PAY_BANK = "Maya" 
    or PAY_BANK = "QRPH"), 
    PAY_CVV int(3) zerofill not null, 
    constraint CHK_PAY_CVV check(1 <= PAY_CVV <= 999), 
    PAY_EXP_DATE date not null, 
    PAY_TYPE enum("Debit", "Credit", "E-wallet") not null, 
    constraint CHK_PAY_TYPE check(PAY_TYPE = "Debit" 
    or PAY_TYPE = "Credit" 
    or PAY_TYPE = "E-wallet"), 
    PAY_CARD_NUM int not null, 
    PAY_CARD_NAME varchar(100) not null
); 

create table adviser(
	ADV_ID int(10) zerofill primary key not null,
    constraint CHK_ADV_ID check(1 <= ADV_ID <= 9999999999), 
    ADV_NAME varchar(100) not null, 
    ADV_GENDER enum("Male", "Female") not null, 
    constraint CHK_ADV_GENDER check(ADV_GENDER = "Male" 
    or ADV_GENDER = "Female"),
    ADV_SUBJECT varchar(100) not null, 
    ADV_SECTION char(7) not null, 
    ADV_DEGREE varchar(100) not null,
    ADV_POSIITION varchar(100) not null, 
    ADV_UNITS_HANDLE int not null
    constraint CHK_ADV_UNITS_HANDLE check(1 <= ADV_UNITS_HANDLE <= 12)
); 

create table program(
	PROG_SECTIONS int primary key not null, 
    constraint CHK_PROG_SECTIONS check(1 <= PROG_SECTIONS <= 20), 
    PROG_FK1_ADV_ID int(10) zerofill not null, 
    foreign key(PROG_FK1_ADV_ID) references adviser(ADV_ID), 
    constraint CHK_PROG_FK1_ADV_ID check(1 <= PROG_FK1_ADV_ID <= 9999999999),
    PROG_COURSES varchar(100) not null, 
    PROG_ENROLLEES int not null, 
    constraint CHK_PROG_ENROLLEES check(1 <= PROG_ENROLLEES <= 999), 
    PROG_TERMS int not null, 
    constraint CHK_PROG_TERMS check(1 <= PROG_TERMS <= 99)
); 

create table fee(
	FEE_BALANCE decimal(6,2) primary key not null, 
    constraint CHK_FEE_BALANCE check(0000.00 <= FEE_BALANCE <= 9999.99), 
    FEE_FK1_PROG_SECTIONS int not null, 
    foreign key(FEE_FK1_PROG_SECTIONS) references program(PROG_SECTIONS), 
    constraint CHK_FEE_FK1_PROG_SECTIONS check(1 <= FEE_FK1_PROG_SECTIONS <= 20),
    FEE_FK2_REG_ID int(10) zerofill not null, 
	foreign key(FEE_FK2_REG_ID) references registrar(REG_ID),
    constraint CHK_FEE_FK2_REG_ID check(1 <= FEE_FK2_REG_ID <= 9999999999),
    FEE_REGISTRATION decimal(6,2) not null, 
    constraint CHK_FEE_REGISTRATION check(0000.00 <= FEE_REGISTRATION <= 9999.99), 
    FEE_LIBRARY decimal(6,2) not null, 
    constraint CHK_FEE_LIBRARY check(0000.00 <= FEE_LIBRARY <= 9999.99), 
    FEE_TUITION decimal(7,2) not null, 
    constraint CHK_FEE_TUITION check(00000.00 <= FEE_TUITION <= 99999.99), 
    FEE_MEDICAL decimal(6,2) not null, 
    constraint CHK_FEE_MEDICAL check(0000.00 <= FEE_MEDICAL <= 9999.99), 
    FEE_MISCELLENEOUS decimal(6,2) not null, 
    constraint CHK_FEE_MISCELLENEOUS check(0000.00 <= FEE_MISCELLENEOUS <= 9999.99), 
    FEE_RESERVATION decimal(6,2) not null, 
    constraint CHK_FEE_RESERVATION check(0000.00 <= FEE_RESERVATION <= 9999.99)
); 

create table student(
	STUD_ID int(10) zerofill primary key not null, 
    constraint CHK_STUD_ID check(1 <= STUD_ID <= 9999999999),
	STUD_FK1_PROG_SECTIONS int not null, 
    foreign key(STUD_FK1_PROG_SECTIONS) references program(PROG_SECTIONS), 
    constraint CHK_STUD_FK1_PROG_SECTIONS check(1 <= STUD_FK1_PROG_SECTIONS <= 20),
    STUD_FK2_PAY_BANK enum("BDO", "BPI", "Metrobank", 
    "Gcash", "Maya", "QRPH") not null,
    foreign key(STUD_FK2_PAY_BANK) references payment_method(PAY_BANK), 
    constraint CHK_STUD_FK2_PAY_BANK check(STUD_FK2_PAY_BANK = "BDO" 
    or STUD_FK2_PAY_BANK = "BPI"
    or STUD_FK2_PAY_BANK = "Gcash" 
    or STUD_FK2_PAY_BANK = "Maya" 
    or STUD_FK2_PAY_BANK = "QRPH"), 
    STUD_FK3_REG_ID int(10) zerofill not null, 
    foreign key(STUD_FK3_REG_ID) references registrar(REG_ID), 
    constraint CHK_STUD_FK3_REG_ID check(1 <= STUD_FK3_REG_ID <= 9999999999),
    STUD_NAME varchar(100) not null, 
    STUD_ADDRESS varchar(100) not null, 
    STUD_GENDER enum("Male", "Female") not null, 
    constraint CHK_STUD_GENDER check(STUD_GENDER = "Male" 
    or STUD_GENDER = "Female"),
    STUD_AGE int not null, 
    constraint CHK_STUD_AGE check(18 <= STUD_AGE <= 70),
    STUD_YEAR_LVL int not null, 
    constraint CHK_STUD_YEAR_LVL check(1 <= STUD_YEAR_LVL <= 9),
    STUD_SECTION varchar(7) not null, 
    STUD_STATUS enum("Regular", "Irregular", "Graduated"),
    constraint CHK_STUD_STATUS check(STUD_STATUS = "Regular" 
    or STUD_STATUS = "Irregular"
    or STUD_STATUS = "Graduated"),
    STUD_SCHOLARSHIP enum("None", "Partial", "Full"), 
    constraint CHK_STUD_SCHOLARSHIP check(STUD_SCHOLARSHIP= "None" 
    or STUD_SCHOLARSHIP = "Partial"
    or STUD_SCHOLARSHIP = "Full")
); 