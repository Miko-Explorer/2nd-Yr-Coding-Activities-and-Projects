#creation of database and tables:
create database hogwarts_enrollment_sys_fin_ver_3; 

use hogwarts_enrollment_sys_fin_ver_3; 

create table admins(
	ADMINS_ID int(10) zerofill primary key not null, 
    ADMINS_NAME varchar(100) not null
); 

create table payment_method(
	METHOD_ID int(10) zerofill primary key not null, 
    METHOD_TYPE enum("Credit", "Debit", "E-wallet", "None") not null
); 

create table adviser(
	ADV_ID int(10) zerofill primary key not null, 
    ADV_NAME varchar(100) not null, 
    ADV_HANDLED_SECTIONS int not null,
    constraint chk_ADV_HANDLED_SECTIONS check(ADV_HANDLED_SECTIONS >= 1 and ADV_HANDLED_SECTIONS <= 99), 
    ADV_UNITS_HANDLE int not null, 
    constraint chk_ADV_UNITS_HANDLE check(ADV_UNITS_HANDLE >= 1 and ADV_UNITS_HANDLE <= 12)
); 

create table program(
	PROG_ID int(3) zerofill primary key not null, 
    constraint chk_PROG_ID check (PROG_ID >= 001 and PROG_ID <= 200), 
    PROG_NAME varchar(200) not null, 
    PROG_SECTIONS int not null, 
    constraint chk_PROG_SECTIONS check(PROG_SECTIONS >= 1 and PROG_SECTIONS <= 9), 
    PROG_ENROLLEES int not null, 
    constraint chk_PROG_ENROLLEES check(PROG_ENROLLEES >= 1 and PROG_ENROLLEES <= 999), 
    PROG_TOTAL_UNITS int not null, 
    constraint chk_PROG_TOTAL_UNITS check(PROG_TOTAL_UNITS >= 144 and PROG_TOTAL_UNITS <= 245), 
    PROG_TERMS int not null, 
    constraint chk_PROG_TERMS check(PROG_TERMS >= 1 and PROG_TERMS <= 9)
); 

create table student(
	STUD_ID int(10) zerofill primary key not null, 
    PROG_ID int(3) zerofill not null, 
    foreign key(PROG_ID) references program(PROG_ID), 
    STUD_NAME varchar(100) not null, 
    STUD_ADDRESS varchar(100) not null, 
    STUD_AGE int not null, 
    constraint chk_STUD_AGE check(STUD_AGE >= 18 and STUD_AGE <= 70), 
    STUD_SCHOLARSHIP enum("None", "Partial", "Full") not null
); 

create table fee(
	FEE_INVOICE int(10) zerofill primary key not null, 
    STUD_ID int(10) zerofill not null,  
    foreign key(STUD_ID) references student(STUD_ID), 
    FEE_AMOUNT decimal(7,2) not null default 0.00, 
    constraint chk_FEE_AMOUNT check(FEE_AMOUNT >= 0.00 and FEE_AMOUNT <= 99999.99), 
    FEE_STATUS enum("Paid", "Incomplete", "None") not null
); 

create table payment(
	PAY_INVOICE int(10) zerofill primary key not null, 
    FEE_INVOICE int(10) zerofill not null, 
    foreign key(FEE_INVOICE) references fee(FEE_INVOICE), 
    METHOD_ID int(10) zerofill not null, 
    foreign key(METHOD_ID) references payment_method(METHOD_ID),
    PAY_DATE date not null, 
    constraint chk_PAY_DATE check(PAY_DATE >= '2025-01-01' and PAY_DATE <= '2030-12-31'), 
    PAY_AMOUNT decimal(7,2) not null default 0.00, 
    constraint chk_PAY_AMOUNT check(PAY_AMOUNT >= 0.00 and PAY_AMOUNT <= 99999.99), 
    PAY_OPTIONS enum("Full payment", "Installment", "None") not null
); 

create table enrollment(
	ENR_ID int(10) zerofill primary key not null, 
    ADMINS_ID int(10) zerofill not null, 
    foreign key(ADMINS_ID) references admins(ADMINS_ID), 
    STUD_ID int(10) zerofill not null, 
    foreign key(STUD_ID) references student(STUD_ID), 
    ENR_DATE date not null, 
    constraint chk_ENR_DATE check(ENR_DATE >= '2025-01-01' and ENR_DATE <= '2025-02-01'), 
    ENR_STATUS enum("Registered", "Enrolled", "Dropped", "Withdrawn", "Completed", "Failed", "None") not null
); 

#Check newly updated and added table/entities for our database:
describe admins; 

describe payment_method; 

describe adviser; 

describe program; 

describe student; 

describe fee; 

describe payment; 

describe enrollment; 