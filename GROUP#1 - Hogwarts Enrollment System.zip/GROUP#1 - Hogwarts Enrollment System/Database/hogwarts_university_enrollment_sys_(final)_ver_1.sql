create database hogwarts_enrollment_sys_fin_ver_1;

use hogwarts_enrollment_sys_fin_ver_1; 

create table registrar(
	REG_ID varchar(12) primary key not null, 
    REG_NAME varchar(100) not null, 
    REG_AGE int not null, 
    constraint chk_REG_AGE check(REG_AGE >= 18 and REG_AGE <= 99), 
    REG_GENDER enum("Male", "Female") not null
); 

create table payment_method(
	PAY_INVOICE varchar(12) primary key not null,
    PAY_CVV int(3) zerofill not null,
    constraint chk_PAY_CVV check(PAY_CVV >= 00 and PAY_CVV <= 999), 
    PAY_DEADLINE date not null, 
    constraint chk_PAY_DEADLINE check(PAY_DEADLINE >= '2025-01-01' and PAY_DEADLINE <= '2030-12-31'), 
    PAY_TYPE enum("Debit", "Credit", "E-wallet") not null, 
    PAY_CARD_NUM int not null 
); 

create table program(
	PROG_ID varchar(12) primary key not null, 
    PROG_SECTIONS int not null, 
    constraint chk_PROG_SECTIONS check(PROG_SECTIONS >= 1 and PROG_SECTIONS <= 20), 
    PROG_COURSES varchar(100) not null, 
    PROG_ENROLLEES int not null, 
    constraint chk_PROG_ENROLLLEES check(PROG_ENROLLEES >= 1 and PROG_ENROLLEES <= 999), 
    PROG_TERMS int not null
    constraint chk_PROG_TERMS check(PROG_TERMS >= 1 and PROG_TERMS <= 9)
);

create table adviser(
	ADV_ID varchar(12) primary key not null, 
    PROG_ID varchar(12) not null, 
    foreign key(PROG_ID) references program(PROG_ID), 
    ADV_NAME varchar(100) not null, 
    ADV_HANDLED_COURSES varchar(100) not null, 
    ADV_HANDLED_SECTIONS int not null, 
    constraint chk_ADV_HANDLED_SECTIONS check(ADV_HANDLED_SECTIONS >= 1 and ADV_HANDLED_SECTIONS <= 99), 
    ADV_UNITS_HANDLE int not null, 
    constraint chk_ADV_UNITS_HANDLE check(ADV_UNITS_HANDLE >= 1 and ADV_UNITS_HANDLE <= 12)
); 

create table fee(
	FEE_INVOICE varchar(12) primary key not null, 
    PROG_ID varchar(12) not null,
    foreign key(PROG_ID) references program(PROG_ID), 
    REG_ID varchar(12) not null, 
    foreign key(REG_ID) references registrar(REG_ID), 
    FEE_BALANCE decimal(6,2) not null, 
    constraint chk_FEE_BALANCE check(FEE_BALANCE >= 0.00 and FEE_BALANCE <= 9999.99), 
    FEE_REGISTRATION decimal(6,2) not null, 
    constraint chk_FEE_REGISTRATION check(FEE_REGISTRATION >= 0.00 and FEE_REGISTRATION <= 9999.99),
    FEE_TUITION decimal(7,2) not null, 
    constraint chk_FEE_TUITION check(FEE_TUITION >= 30000.00 and FEE_TUITION <= 99999.99), 
    FEE_MISCELLANEOUS decimal(6,2) not null, 
    constraint chk_FEE_MISCELLANEOUS check(FEE_MISCELLANEOUS >= 0.00 and FEE_MISCELLANEOUS <= 9999.99),
    FEE_RESERVATION decimal(6,2) not null
    constraint chk_FEE_RESERVATION check(FEE_RESERVATION >= 0.00 and FEE_RESERVATION <= 9999.99)
); 

create table student(
	STUD_ID varchar(12) primary key not null, 
    PROG_ID varchar(12) not null, 
    foreign key(PROG_ID) references program(PROG_ID), 
    PAY_INVOICE varchar(12) not null, 
    foreign key(PAY_INVOICE) references payment_method(PAY_INVOICE), 
    REG_ID varchar(12) not null, 
    foreign key(REG_ID) references registrar(REG_ID), 
    STUD_NAME varchar(100) not null, 
    STUD_ADDRESS varchar(100) not null, 
    STUD_AGE int not null,
    constraint chk_STUD_AGE check(STUD_AGE >= 18 and STUD_AGE <= 70), 
    STUD_YEAR_LVL int not null, 
    constraint chk_STUD_YEAR_LVL check(STUD_YEAR_LVL >= 1 and STUD_YEAR_LVL <= 9), 
    STUD_STATUS enum("Regular", "Irregular", "Graduated") not null, 
    STUD_SCHOLARSHIP enum("None", "Partial", "Full") not null
); 

#Check if tables are in line with our data dictionary
describe registrar; 

describe program; 

describe registrar; 

describe adviser; 

describe student; 