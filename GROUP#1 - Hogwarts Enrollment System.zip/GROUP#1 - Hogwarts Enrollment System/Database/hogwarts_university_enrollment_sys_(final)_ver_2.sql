#creation of database and tables:
create database hogwarts_enrollment_sys_fin_ver_2; 

use hogwarts_enrollment_sys_fin_ver_2; 

create table admins(
	ADMINS_ID varchar(14) primary key not null, 
    ADMINS_NAME varchar(100) not null
); 

create table payment_method(
	METHOD_ID varchar(14) primary key not null, 
    METHOD_TYPE enum("Credit", "Debit", "E-wallet", "None") not null
); 

create table adviser(
	ADV_ID varchar(12) primary key not null, 
    ADV_NAME varchar(100) not null, 
    ADV_HANDLED_SECTIONS int not null,
    constraint chk_ADV_HANDLED_SECTIONS check(ADV_HANDLED_SECTIONS >= 1 and ADV_HANDLED_SECTIONS <= 99), 
    ADV_UNITS_HANDLE int not null, 
    constraint chk_ADV_UNITS_HANDLE check(ADV_UNITS_HANDLE >= 1 and ADV_UNITS_HANDLE <= 12)
); 

create table program(
	PROG_ID varchar(12) primary key not null, 
    PROG_NAME varchar(200) not null, 
    PROG_SECTIONS int not null, 
    constraint chk_PROG_SECTIONS check(PROG_SECTIONS >= 1 and PROG_SECTIONS <= 9), 
    PROG_ENROLLEES int not null, 
    constraint chk_PROG_ENROLLEES check(PROG_ENROLLEES >= 1 and PROG_ENROLLEES <= 999), 
    PROG_TOTAL_UNITS int not null, 
    constraint chk_PROG_TOTAL_UNITS check(PROG_TOTAL_UNITS >= 144 and PROG_TOTAL_UNITS <= 245), 
    PROG_TERMS int not null, 
    constraint chk_PROG_TERMS check(PROG_TERMS >= 1 and PROG_TERMS <= 9)
); 

create table student(
	STUD_ID varchar(12) primary key not null, 
    PROG_ID varchar(12) not null, 
    foreign key(PROG_ID) references program(PROG_ID), 
    STUD_NAME varchar(100) not null, 
    STUD_ADDRESS varchar(100) not null, 
    STUD_AGE int not null, 
    constraint chk_STUD_AGE check(STUD_AGE >= 18 and STUD_AGE <= 70), 
    STUD_YEAR_LVL int not null, 
    constraint chk_STUD_YEAR_LVL check(STUD_YEAR_LVL >= 1 and STUD_YEAR_LVL <= 9), 
    STUD_SCHOLARSHIP enum("None", "Partial", "Full") not null
); 

create table fee(
	FEE_INVOICE varchar(14) primary key not null, 
    STUD_ID varchar(12) not null,  
    foreign key(STUD_ID) references student(STUD_ID), 
    FEE_AMOUNT decimal(7,2) not null default 0.00, 
    constraint chk_FEE_AMOUNT check(FEE_AMOUNT >= 0.00 and FEE_AMOUNT <= 99999.99), 
    FEE_OPTIONS enum("Tuition", "Reservation", "Registration", "Miscellaneous", "None") not null, 
    FEE_STATUS enum("Installment", "Full payment", "None") not null
); 

create table payment(
	PAY_INVOICE varchar(14) primary key not null, 
    FEE_INVOICE varchar(14) not null, 
    foreign key(FEE_INVOICE) references fee(FEE_INVOICE), 
    METHOD_ID varchar(14) not null, 
    foreign key(METHOD_ID) references payment_method(METHOD_ID),
    PAY_DATE date not null, 
    constraint chk_PAY_DATE check(PAY_DATE >= '2025-01-01' and PAY_DATE <= '2030-12-31'), 
    PAY_AMOUNT decimal(7,2) not null default 0.00, 
    constraint chk_PAY_AMOUNT check(PAY_AMOUNT >= 0.00 and PAY_AMOUNT <= 99999.99)
); 

create table enrollment(
	ENR_ID varchar(12) primary key not null, 
    ADMINS_ID varchar(14) not null, 
    foreign key(ADMINS_ID) references admins(ADMINS_ID), 
    STUD_ID varchar(12) not null, 
    foreign key(STUD_ID) references student(STUD_ID), 
    ENR_DATE date not null, 
    constraint chk_ENR_DATE check(ENR_DATE >= '2025-01-01' and ENR_DATE <= '2025-02-01'), 
    ENR_STATUS enum("Registered", "Enrolled", "Dropped", "Wuthdrawn", "Completed", "Failed", "None") not null
); 

#Check newly updated and added table/entities for our database:
describe admins; 

describe payment_method; 

describe adviser; 

describe program; 

describe student; 

describe fee; 

describe payment; 

describe enrollment; 