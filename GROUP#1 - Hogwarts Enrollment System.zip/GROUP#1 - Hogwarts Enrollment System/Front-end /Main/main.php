<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="main_design.css?v=1">
	<link rel="icon" type="image/png" href="https://www.pngmart.com/files/12/Sorting-Hat-PNG-Free-Download.png">
    <title>Hogwarts University Database</title>
</head>
<body>
    <h1>Hogwarts University Database</h1>

    <div class="buttons">
        <button onclick="location.href='admin_login.php'">Registrar/Admin</button>
        <button onclick="location.href='student_main.php'">Student</button>
    </div>
</body>
</html>