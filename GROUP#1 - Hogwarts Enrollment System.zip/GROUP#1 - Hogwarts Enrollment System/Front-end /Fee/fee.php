<?php
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {  // check if can connect
        die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
    } else {
        echo "Successfully opened $database";
    }

    $sql = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.FEE";
    $result = $mysqli->query($sql);
    $mysqli->close();

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="fee_design.css">
    <title>Hogwarts University Fee Database</title>
</head>
<body>
<table>
    <tr>
        <th>Fee Invoice</th>
        <th>Student ID</th>
        <th>Fee Amount</th>
        <th>Fee Status</th>
    </tr>
    <?php
    while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo "FEE-" . $row['FEE_INVOICE'];?></td>
            <td><?php echo "S-" . $row['STUD_ID'];?></td>
            <td><?php echo $row['FEE_AMOUNT'];?></td>
            <td><?php echo $row['FEE_STATUS'];?></td>
        </tr>
        <?php
    }
    ?>
</table>
<br>
<form action="fee_functions.php" method="POST">
    <label for="FEE_INVOICE">Fee Invoice:</label>
    <input type="number" name="FEE_INVOICE" min="1" max="9999999999" step="1" required><br>

    <label for="STUD_ID">Student ID:</label>
    <input type="text" name="STUD_ID" min="1" max="9999999999" required><br>

    <label for="FEE_AMOUNT">Fee Amount:</label>
    <input type="number" name="FEE_AMOUNT" min="0" max="99999.99" step="0.01" required><br>
	
	<label for="FEE_STATUS">Fee Status:</label>
    <select name="FEE_STATUS" id="FEE_STATUS" required>
        <option value="None">None</option>
        <option value="Paid">Paid</option>
        <option value="Incomplete">Incomplete</option>
    </select><br>

    <div class="buttons">
        <input type="submit" name="insert" value="Insert">
        <input type="submit" name="update" value="Update">
        <input type="submit" name="delete" value="Delete">
        <button onclick="location.href='admin_main.php'">Return</button>
    </div>
</form>
</body>
</html>