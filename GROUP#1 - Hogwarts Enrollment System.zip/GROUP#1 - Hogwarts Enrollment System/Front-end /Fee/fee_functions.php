<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {
        die('Connect Error(' . $mysqli->maxdb_connect_errorno() . ')' . $mysqli->maxdb_connect_error());
    }

    $FEE_INVOICE = $_REQUEST['FEE_INVOICE'];
    $STUD_ID = $_REQUEST['STUD_ID'];
    $FEE_AMOUNT = $_REQUEST['FEE_AMOUNT'];
    $FEE_STATUS = $_REQUEST['FEE_STATUS'];

    if (isset($_POST['insert'])) {
        $foreign_check = $mysqli->query("SELECT STUD_ID FROM hogwarts_enrollment_sys_fin_ver_3.STUDENT WHERE STUD_ID = '$STUD_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Student ID does not exist";
            exit;
        }
        $check = $mysqli->query("SELECT FEE_INVOICE FROM hogwarts_enrollment_sys_fin_ver_3.FEE WHERE FEE_INVOICE='$FEE_INVOICE'");
        if ($check->num_rows > 0) {
            echo "Duplicate entry detected";
        } else {
            $sql = "INSERT INTO hogwarts_enrollment_sys_fin_ver_3.FEE(FEE_INVOICE, STUD_ID, FEE_AMOUNT, FEE_STATUS) VALUES ('$FEE_INVOICE', '$STUD_ID', '$FEE_AMOUNT', '$FEE_STATUS')";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data inserted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['delete'])) {
        $check = $mysqli->query("SELECT FEE_INVOICE FROM hogwarts_enrollment_sys_fin_ver_3.FEE WHERE FEE_INVOICE='$FEE_INVOICE'");
        if ($check->num_rows === 0) {
            echo "Record doesn't exist";
        } else {
            $sql = "DELETE FROM hogwarts_enrollment_sys_fin_ver_3.FEE WHERE FEE_INVOICE='$FEE_INVOICE'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data deleted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['update'])) {
        $foreign_check = $mysqli->query("SELECT STUD_ID FROM hogwarts_enrollment_sys_fin_ver_3.STUDENT WHERE STUD_ID = '$STUD_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Student ID does not exist";
            exit;
        }
        $origin = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.FEE WHERE FEE_INVOICE='$FEE_INVOICE'";
        $result = $mysqli->query($origin);
        if ($result->num_rows == 0) {
            echo "Record doesn't exist";
        } else {
            $row = $result->fetch_assoc();

            if ($STUD_ID !== "" and $STUD_ID != $row['STUD_ID']) {
                $STUD_ID = $STUD_ID;
            } else {
                $STUD_ID = $row["STUD_ID"];
            }
            if ($FEE_AMOUNT !== "" and $FEE_AMOUNT != $row['FEE_AMOUNT']) {
                $FEE_AMOUNT = $FEE_AMOUNT;
            } else {
                $FEE_AMOUNT = $row["FEE_AMOUNT"];
            }
            if ($FEE_STATUS !== "" and $FEE_STATUS != $row['FEE_STATUS']) {
                $FEE_STATUS = $FEE_STATUS;
            } else {
                $FEE_STATUS = $row["FEE_STATUS"];
            }
            $sql = "UPDATE hogwarts_enrollment_sys_fin_ver_3.FEE SET STUD_ID = '$STUD_ID', FEE_AMOUNT = '$FEE_AMOUNT', FEE_STATUS = '$FEE_STATUS' WHERE FEE_INVOICE='$FEE_INVOICE'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data updated successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }
    $mysqli->close();
?>

<html>
<head>
</head>
<body>
<form action="fee.php" method="POST">
    <input type="submit" value="Return">
</form>
</body>
</html>
