<?php
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {  // check if can connect
        die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
    } else {
        echo "Successfully opened $database";
    }

    $sql = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.admins";
    $result = $mysqli->query($sql);
    $mysqli->close();

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="admins_design.css">
    <title>Hogwarts University Admins Database</title>
</head>
<body>
    <table>
        <tr>
            <th>ADMINS ID</th>
            <th>ADMINS NAME</th>
        </tr>
        <?php
            while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo 'ADM-' . $row['ADMINS_ID'];?></td>
            <td><?php echo $row['ADMINS_NAME'];?></td>
        </tr>
        <?php
            }
        ?>
    </table>
    <br>
    <form action="admins_functions.php" method="POST">
        <label for="ADMINS_ID">Admins ID:</label>
        <input type="number" name="ADMINS_ID" min="1" max="9999999999" step="1" required><br>

        <label for="ADMINS_NAME">Admins Name:</label>
        <input type="text" name="ADMINS_NAME" required pattern="[A-Za-z\s]+" title="Name must only contain letters and spaces"><br>

        <div class="buttons">
            <input type="submit" name="insert" value="Insert">
            <input type="submit" name="update" value="Update">
            <input type="submit" name="delete" value="Delete">
            <button onclick="location.href='admin_main.php'">Return</button>
        </div>
    </form>
</body>
</html>