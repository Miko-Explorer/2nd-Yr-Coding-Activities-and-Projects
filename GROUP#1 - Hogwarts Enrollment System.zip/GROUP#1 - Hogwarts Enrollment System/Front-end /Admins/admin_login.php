<!DOCTYPE html>
<head>
	<title>Log-in</title>
	<link rel="stylesheet" href="admin_login_design.css">
</head>
<body>
	<h1>Log-in</h1>
	
	<div class="login">
		<label for="ADMINS_NAME">Name:</label>
		<input type="text" name="ADMINS_NAME" required ><br>
		
		<label for="ADMINS_ID">ID:</label>
		<input type="number" name="ADMINS_ID" min="1" max="9999999999" step="1" required><br>
		
		<button onclick="location.href='admin_main.php'">Login</button>
	</div>
</body>