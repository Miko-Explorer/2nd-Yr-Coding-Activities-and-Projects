<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {
        die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
    }

    $ADMINS_ID = $_REQUEST['ADMINS_ID'];
    $ADMINS_NAME = $_REQUEST['ADMINS_NAME'];

    if (isset($_POST['insert'])) {
        $check = $mysqli->query("SELECT ADMINS_ID FROM hogwarts_enrollment_sys_fin_ver_3.ADMINS WHERE ADMINS_ID='$ADMINS_ID'");
        if ($check->num_rows > 0) {
            echo "Duplicate entry detected";
        } else {
            $sql = "INSERT INTO hogwarts_enrollment_sys_fin_ver_3.ADMINS(ADMINS_ID, ADMINS_NAME) VALUES ('$ADMINS_ID', '$ADMINS_NAME')";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data inserted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['delete'])) {
        $check = $mysqli->query("SELECT ADMINS_ID FROM hogwarts_enrollment_sys_fin_ver_3.ADMINS WHERE ADMINS_ID='$ADMINS_ID'");
        if ($check->num_rows === 0) {
            echo "Record doesn't exist";
        } else {
            $sql = "DELETE FROM hogwarts_enrollment_sys_fin_ver_3.ADMINS WHERE ADMINS_ID='$ADMINS_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data deleted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['update'])) {
        $origin = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.ADMINS WHERE ADMINS_ID='$ADMINS_ID'";
        $result = $mysqli->query($origin);
        if ($result->num_rows == 0) {
            echo "Record doesn't exist";
        } else {
            $row = $result->fetch_assoc();

            if ($ADMINS_NAME !== "" AND $ADMINS_NAME != $row['ADMINS_NAME']) {
                $ADMINS_NAME = $ADMINS_NAME;
            } else {
                $ADMINS_NAME = $row["ADMINS_NAME"];
            }

            $sql = "UPDATE hogwarts_enrollment_sys_fin_ver_3.ADMINS SET ADMINS_NAME = '$ADMINS_NAME' WHERE ADMINS_ID='$ADMINS_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data updated successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }
    $mysqli->close();
?>

<html>
<head>
</head>
<body>
    <form action="admins.php" method="POST">
        <input type="submit" value="Return">
    </form>
</body>
</html>
