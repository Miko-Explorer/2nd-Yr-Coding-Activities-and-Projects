<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="admin_main_design.css">
	<title>Admin Database</title>
</head>
<body>
	<div class="background"></div>
	<div class="return_button">
		<button onclick="location.href='main.php'">Return</button>
	</div>
    <h1>Admin Database</h1>

    <div class="buttons">
        <button onclick="location.href='admins.php'">Admins Database</button>
        <button onclick="location.href='payment%20method.php'">Payment Method Database</button>
        <button onclick="location.href='program.php'">Program Database</button>
        <button onclick="location.href='adviser.php'">Adviser Database</button>
		<button onclick="location.href='student.php'">Student Database</button>
        <button onclick="location.href='fee.php'">Fee Database</button>
		<button onclick="location.href='payment.php'">Payment Database</button>
		<button onclick="location.href='enrollment.php'">Enrollment Database</button>
    </div>
	
</body>
</html>