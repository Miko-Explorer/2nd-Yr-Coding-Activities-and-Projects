<?php
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {  // check if can connect
        die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
    } else {
        echo "Successfully opened $database";
    }

    $sql = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.PROGRAM";
    $result = $mysqli->query($sql);
    $mysqli->close();

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="program_design.css">
    <title>Hogwarts University Program Database</title>
</head>
<body>
<table>
    <tr>
        <th>Program ID</th>
        <th>Program Name</th>
        <th>Program Sections</th>
        <th>Program Enrollees</th>
        <th>Program Total Units</th>
		<th>Program Terms</th>
    </tr>
    <?php
    while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo "P-" . $row['PROG_ID'];?></td>
            <td><?php echo $row['PROG_NAME'];?></td>
            <td><?php echo $row['PROG_SECTIONS'];?></td>
            <td><?php echo $row['PROG_ENROLLEES'];?></td>
            <td><?php echo $row['PROG_TOTAL_UNITS'];?></td>
			<td><?php echo $row['PROG_TERMS'];?></td>
        </tr>
        <?php
    }
    ?>
</table>
<br>
<form action="program_functions.php" method="POST">
    <label for="PROG_ID">Program ID:</label>
    <input type="number" name="PROG_ID" min="1" max="200" step="1" required><br>
	
	<label for="PROG_NAME">Program Name:</label>
    <input type="text" name="PROG_NAME" required><br>

    <label for="PROG_SECTIONS">Program Sections:</label>
    <input type="number" name="PROG_SECTIONS" min="1" max="20" required><br>

    <label for="PROG_ENROLLEES">Program Enrollees:</label>
    <input type="number" name="PROG_ENROLLEES" min="1" max="999" required><br>

	<label for="PROG_TOTAL_UNITS">Program Total Units:</label>
    <input type="number" name="PROG_TOTAL_UNITS" min="144" max="245" required><br>
	
    <label for="PROG_TERMS">Program Terms:</label>
    <input type="number" name="PROG_TERMS" min="1" max="9" required><br>

    <div class="buttons">
        <input type="submit" name="insert" value="Insert">
        <input type="submit" name="update" value="Update">
        <input type="submit" name="delete" value="Delete">
        <button onclick="location.href='admin_main.php'">Return</button>
    </div>
</form>
</body>
</html>