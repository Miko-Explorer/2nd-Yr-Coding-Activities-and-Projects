<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {
        die('Connect Error(' . $mysqli->maxdb_connect_errorno() . ')' . $mysqli->maxdb_connect_error());
    }

    $PROG_ID = $_REQUEST['PROG_ID'];
	$PROG_NAME = $_REQUEST['PROG_NAME'];
    $PROG_SECTIONS = $_REQUEST['PROG_SECTIONS'];
    $PROG_ENROLLEES = $_REQUEST['PROG_ENROLLEES'];
	$PROG_TOTAL_UNITS = $_REQUEST['PROG_TOTAL_UNITS'];
    $PROG_TERMS = $_REQUEST['PROG_TERMS'];

    if (isset($_POST['insert'])) {
        $check = $mysqli->query("SELECT PROG_ID FROM hogwarts_enrollment_sys_fin_ver_3.PROGRAM WHERE PROG_ID='$PROG_ID'");
        if ($check->num_rows > 0) {
            echo "Duplicate entry detected";
        } else {
            $sql = "INSERT INTO hogwarts_enrollment_sys_fin_ver_3.PROGRAM(PROG_ID, PROG_NAME, PROG_SECTIONS, PROG_ENROLLEES, PROG_TOTAL_UNITS, PROG_TERMS) VALUES ('$PROG_ID', '$PROG_NAME', '$PROG_SECTIONS', '$PROG_ENROLLEES', '$PROG_TOTAL_UNITS', '$PROG_TERMS')";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data inserted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['delete'])) {
        $check = $mysqli->query("SELECT PROG_ID FROM hogwarts_enrollment_sys_fin_ver_3.PROGRAM WHERE PROG_ID='$PROG_ID'");
        if ($check->num_rows === 0) {
            echo "Record doesn't exist";
        } else {
            $sql = "DELETE FROM hogwarts_enrollment_sys_fin_ver_3.PROGRAM WHERE PROG_ID='$PROG_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data deleted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['update'])) {
        $origin = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.PROGRAM WHERE PROG_ID='$PROG_ID'";
        $result = $mysqli->query($origin);
        if ($result->num_rows == 0) {
            echo "Record doesn't exist";
        } else {
            $row = $result->fetch_assoc();
			
			if ($PROG_NAME !== "" and $PROG_NAME != $row['PROG_NAME']) {
                $PROG_NAME = $PROG_NAME;
            } else {
                $PROG_NAME = $row["PROG_NAME"];
            }
            if ($PROG_SECTIONS !== "" and $PROG_SECTIONS != $row['PROG_SECTIONS']) {
                $PROG_SECTIONS = $PROG_SECTIONS;
            } else {
                $PROG_SECTIONS = $row["PROG_SECTIONS"];
            }
            if ($PROG_ENROLLEES !== "" and $PROG_ENROLLEES != $row['PROG_ENROLLEES']) {
                $PROG_ENROLLEES = $PROG_ENROLLEES;
            } else {
                $PROG_ENROLLEES = $row["PROG_ENROLLEES"];
            }
			if ($PROG_TOTAL_UNITS !== "" and $PROG_TOTAL_UNITS != $row['PROG_TOTAL_UNITS']) {
                $PROG_TOTAL_UNITS = $PROG_TOTAL_UNITS;
            } else {
                $PROG_TOTAL_UNITS = $row["PROG_TOTAL_UNITS"];
            }
            if ($PROG_TERMS !== "" and $PROG_TERMS != $row['PROG_TERMS']) {
                $PROG_TERMS = $PROG_TERMS;
            } else {
                $PROG_TERMS = $row["PROG_TERMS"];
            }
            $sql = "UPDATE hogwarts_enrollment_sys_fin_ver_3.PROGRAM SET PROG_NAME = '$PROG_NAME', PROG_SECTIONS = '$PROG_SECTIONS', PROG_ENROLLEES = '$PROG_ENROLLEES', PROG_TOTAL_UNITS = '$PROG_TOTAL_UNITS', PROG_TERMS = '$PROG_TERMS' WHERE PROG_ID='$PROG_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data updated successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }
    $mysqli->close();
?>

<html>
<head>
</head>
<body>
<form action="program.php" method="POST">
    <input type="submit" value="Return">
</form>
</body>
</html>
