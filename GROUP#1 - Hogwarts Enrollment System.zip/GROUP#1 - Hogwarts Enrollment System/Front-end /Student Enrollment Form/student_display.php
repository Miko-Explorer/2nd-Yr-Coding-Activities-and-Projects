<!DOCTYPE html>
<html>
<head>
	<style>
		table {
			border-collapse: collapse;
			width: 100%;
		}

		th {
			padding: 10px 20px;
			border: 2px solid #ccc;
			text-align: center;
		}

		td {
			padding: 10px 20px;
			border: 2px solid #ccc;
			text-align: center;
		}
		
		button {
			margin-left: 10px;
			margin-top: 10px;
		}
	</style>
</head>
<body>
    <?php
	    $STUD_NAME = $_REQUEST['STUD_NAME'];
	    $STUD_ADDRESS = $_REQUEST['STUD_ADDRESS'];
	    $STUD_AGE = $_REQUEST['STUD_AGE'];
	    $STUD_SCHOLARSHIP = $_REQUEST['STUD_SCHOLARSHIP'];
	    $PROG_NAME = $_REQUEST['PROG_NAME'];
	    $PAY_AMOUNT = $_REQUEST['PAY_AMOUNT'];
	    $METHOD_TYPE = $_REQUEST['METHOD_TYPE'];
	    $FEE_STATUS = $_REQUEST['FEE_STATUS'];
	
		
    ?>
	
	<table>
	<tr>
		<th>Name</th>
		<th>Address</th>
		<th>Age</th>
		<th>Scholarship</th>
		<th>Program Name</th>
		<th>Payment Amount</th>
		<th>Payment Method</th>
		<th>Fee Status</th>
	</tr>
	<tr>
		<td><?php echo $STUD_NAME; ?></td>
		<td><?php echo $STUD_ADDRESS; ?></td>
		<td><?php echo $STUD_AGE; ?></td>
		<td><?php echo $STUD_SCHOLARSHIP; ?></td>
		<td><?php echo $PROG_NAME; ?></td>
		<td><?php echo $PAY_AMOUNT; ?></td>
		<td><?php echo $METHOD_TYPE; ?></td>
		<td><?php echo $FEE_STATUS; ?></td>
	</tr>
	</table>
	
	<button onclick="location.href='student_main.php'">Return</button>
</body>
</html>