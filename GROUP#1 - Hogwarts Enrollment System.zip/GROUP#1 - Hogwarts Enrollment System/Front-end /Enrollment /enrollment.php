<?php
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {  // check if can connect
        die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
    } else {
        echo "Successfully opened $database";
    }

    $sql = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.ENROLLMENT";
    $result = $mysqli->query($sql);
    $mysqli->close();

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="enrollment_design.css">
    <title>Hogwarts University Enrollment Database</title>
</head>
<body>
<table>
    <tr>
        <th>Enrollment ID</th>
        <th>Admins ID</th>
        <th>Student ID</th>
        <th>Enrollment Date</th>
        <th>Enrollment Status</th>
    </tr>
    <?php
    while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo "E-" . $row['ENR_ID'];?></td>
			<td><?php echo "ADM-" . $row['ADMINS_ID'];?></td>
            <td><?php echo "S-" . $row['STUD_ID'];?></td>
            <td><?php echo $row['ENR_DATE'];?></td>
            <td><?php echo $row['ENR_STATUS'];?></td>
        </tr>
        <?php
    }
    ?>
</table>
<br>
<form action="enrollment_functions.php" method="POST">
    <label for="ENR_ID">Enrollment ID:</label>
    <input type="number" name="ENR_ID" min="1" max="9999999999" step="1" required><br>

    <label for="ADMINS_ID">Admins ID:</label>
    <input type="number" name="ADMINS_ID" min="1" max="9999999999" step="1" required><br>

    <label for="STUD_ID">Student ID:</label>
    <input type="number" name="STUD_ID" min="1" max="9999999999" step="1" required><br>

    <label for="ENR_DATE">Enrollment Date:</label>
    <input type="date" name="ENR_DATE" min="2025-01-01" max="2030-02-01" required><br>

	<label for="ENR_STATUS">Enrollment Status:</label>
    <select name="ENR_STATUS" id="ENR_STATUS" required>
		<option value="None">None</option>
        <option value="Registered">Registered</option>
        <option value="Enrolled">Enrolled</option>
        <option value="Dropped">Dropped</option>
		<option value="Withdrawn">Withdrawn</option>
		<option value="Completed">Completed</option>
		<option value="Failed">Failed</option>
    </select><br>

    <div class="buttons">
        <input type="submit" name="insert" value="Insert">
        <input type="submit" name="update" value="Update">
        <input type="submit" name="delete" value="Delete">
        <button onclick="location.href='admin_main.php'">Return</button>
    </div>
</form>
</body>
</html>