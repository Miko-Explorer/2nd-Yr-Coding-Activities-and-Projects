<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {
        die('Connect Error(' . $mysqli->maxdb_connect_errorno() . ')' . $mysqli->maxdb_connect_error());
    }

    $ENR_ID = $_REQUEST['ENR_ID'];
    $ADMINS_ID = $_REQUEST['ADMINS_ID'];
    $STUD_ID = $_REQUEST['STUD_ID'];
    $ENR_DATE = $_REQUEST['ENR_DATE'];
    $ENR_STATUS = $_REQUEST['ENR_STATUS'];

    if (isset($_POST['insert'])) {
        $foreign_check = $mysqli->query("SELECT ADMINS_ID FROM hogwarts_enrollment_sys_fin_ver_3.ADMINS WHERE ADMINS_ID = '$ADMINS_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Admin ID does not exist";
            exit;
        }
		$foreign_check = $mysqli->query("SELECT STUD_ID FROM hogwarts_enrollment_sys_fin_ver_3.STUDENT WHERE STUD_ID = '$STUD_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Student ID does not exist";
            exit;
        }
        $check = $mysqli->query("SELECT ENR_ID FROM hogwarts_enrollment_sys_fin_ver_3.ENROLLMENT WHERE ENR_ID='$ENR_ID'");
        if ($check->num_rows > 0) {
            echo "Duplicate entry detected";
        } else {
            $sql = "INSERT INTO hogwarts_enrollment_sys_fin_ver_3.ENROLLMENT(ENR_ID, ADMINS_ID, STUD_ID, ENR_DATE, ENR_STATUS) VALUES ('$ENR_ID', '$ADMINS_ID', '$STUD_ID', '$ENR_DATE', '$ENR_STATUS')";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data inserted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['delete'])) {
        $check = $mysqli->query("SELECT ENR_ID FROM hogwarts_enrollment_sys_fin_ver_3.ENROLLMENT WHERE ENR_ID='$ENR_ID'");
        if ($check->num_rows === 0) {
            echo "Record doesn't exist";
        } else {
            $sql = "DELETE FROM hogwarts_enrollment_sys_fin_ver_3.ENROLLMENT WHERE ENR_ID='$ENR_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data deleted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['update'])) {
        $foreign_check = $mysqli->query("SELECT ADMINS_ID FROM hogwarts_enrollment_sys_fin_ver_3.ADMINS WHERE ADMINS_ID = '$ADMINS_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Admin ID does not exist";
            exit;
        }
		$foreign_check = $mysqli->query("SELECT STUD_ID FROM hogwarts_enrollment_sys_fin_ver_3.STUDENT WHERE STUD_ID = '$STUD_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Student ID does not exist";
            exit;
        }
        $origin = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.ENROLLMENT WHERE ENR_ID='$ENR_ID'";
        $result = $mysqli->query($origin);
        if ($result->num_rows == 0) {
            echo "Record doesn't exist";
        } else {
            $row = $result->fetch_assoc();

            if ($ADMINS_ID !== "" and $ADMINS_ID != $row['ADMINS_ID']) {
                $ADMINS_ID = $ADMINS_ID;
            } else {
                $ADMINS_ID = $row["ADMINS_ID"];
            }
			if ($STUD_ID !== "" and $STUD_ID != $row['STUD_ID']) {
                $STUD_ID = $STUD_ID;
            } else {
                $STUD_ID = $row["STUD_ID"];
            }
            if ($ENR_DATE !== "" and $ENR_DATE != $row['ENR_DATE']) {
                $ENR_DATE = $ENR_DATE;
            } else {
                $ENR_DATE = $row["ENR_DATE"];
            }
			if ($ENR_STATUS !== "" and $ENR_STATUS != $row['ENR_STATUS']) {
                $ENR_STATUS = $ENR_STATUS;
            } else {
                $ENR_STATUS = $row["ENR_STATUS"];
            }
            $sql = "UPDATE hogwarts_enrollment_sys_fin_ver_3.ENROLLMENT SET ADMINS_ID = '$ADMINS_ID', STUD_ID = '$STUD_ID', ENR_DATE = '$ENR_DATE', ENR_STATUS = '$ENR_STATUS' WHERE ENR_ID='$ENR_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data updated successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }
    $mysqli->close();
?>

<html>
<head>
</head>
<body>
<form action="enrollment.php" method="POST">
    <input type="submit" value="Return">
</form>
</body>
</html>
