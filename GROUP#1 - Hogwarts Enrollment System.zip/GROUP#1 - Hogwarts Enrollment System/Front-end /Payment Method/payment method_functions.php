<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {
        die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
    }

    $METHOD_ID = $_REQUEST['METHOD_ID'];
    $METHOD_TYPE = $_REQUEST['METHOD_TYPE'];

    if (isset($_POST['insert'])) {
        $check = $mysqli->query("SELECT METHOD_ID FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT_METHOD WHERE METHOD_ID='$METHOD_ID'");
        if ($check->num_rows > 0) {
            echo "Duplicate entry detected";
        } else {
            $sql = "INSERT INTO hogwarts_enrollment_sys_fin_ver_3.PAYMENT_METHOD(METHOD_ID, METHOD_TYPE) VALUES ('$METHOD_ID', '$METHOD_TYPE')";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data inserted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['delete'])) {
        $check = $mysqli->query("SELECT METHOD_ID FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT_METHOD WHERE METHOD_ID='$METHOD_ID'");
        if ($check->num_rows === 0) {
            echo "Record doesn't exist";
        } else {
            $sql = "DELETE FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT_METHOD WHERE METHOD_ID='$METHOD_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data deleted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['update'])) {
        $origin = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT_METHOD WHERE METHOD_ID='$METHOD_ID'";
        $result = $mysqli->query($origin);
        if ($result->num_rows == 0) {
            echo "Record doesn't exist";
        } else {
            $row = $result->fetch_assoc();

            if ($METHOD_TYPE !== "" AND $METHOD_TYPE != $row['METHOD_TYPE']) {
                $METHOD_TYPE = $METHOD_TYPE;
            } else {
                $METHOD_TYPE = $row["METHOD_TYPE"];
            }

            $sql = "UPDATE hogwarts_enrollment_sys_fin_ver_3.PAYMENT_METHOD SET METHOD_TYPE = '$METHOD_TYPE' WHERE METHOD_ID='$METHOD_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data updated successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }
    $mysqli->close();
?>

<html>
<head>
</head>
<body>
<form action="payment%20method.php" method="POST">
    <input type="submit" value="Return">
</form>
</body>
</html>
