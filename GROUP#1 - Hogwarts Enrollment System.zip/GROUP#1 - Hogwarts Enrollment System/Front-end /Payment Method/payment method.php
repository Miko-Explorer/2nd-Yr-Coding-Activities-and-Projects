<?php
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {  // check if can connect
        die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
    } else {
        echo "Successfully opened $database";
    }

    $sql = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT_METHOD";
    $result = $mysqli->query($sql);
    $mysqli->close();

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="payment%20method_design.css">
    <title>Hogwarts University Payment Method Database</title>
</head>
<body>
<table>
    <tr>
        <th>Payment Method ID</th>
        <th>Payment Method Type</th>
    </tr>
    <?php
    while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo "PMD-" . $row['METHOD_ID'];?></td>
            <td><?php echo $row['METHOD_TYPE'];?></td>
        </tr>
        <?php
    }
    ?>
</table>
<br>
<form action="payment%20method_functions.php" method="POST">
    <label for="METHOD_ID">Payment Method ID:</label>
    <input type="number" name="METHOD_ID" min="1" max="9999999999" step="1" required><br>

    <label for="METHOD_TYPE">Payment Method Type:</label>
    <select name="METHOD_TYPE" id="METHOD_TYPE" required>
		<option value="none">None</option>
        <option value="E-wallet">E-wallet</option>
        <option value="Debit">Debit</option>
        <option value="Credit">Credit</option>
    </select><br>


    <div class="buttons">
        <input type="submit" name="insert" value="Insert">
        <input type="submit" name="update" value="Update">
        <input type="submit" name="delete" value="Delete">
        <button onclick="location.href='admin_main.php'">Return</button>
    </div>
</form>
</body>
</html>