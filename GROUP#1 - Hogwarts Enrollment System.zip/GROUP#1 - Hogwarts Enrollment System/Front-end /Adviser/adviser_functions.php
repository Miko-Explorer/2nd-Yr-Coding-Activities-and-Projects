<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {
        die('Connect Error(' . $mysqli->maxdb_connect_errorno() . ')' . $mysqli->maxdb_connect_error());
    }

    $ADV_ID = $_REQUEST['ADV_ID'];
    $ADV_NAME = $_REQUEST['ADV_NAME'];
    $ADV_HANDLED_SECTIONS = $_REQUEST['ADV_HANDLED_SECTIONS'];
    $ADV_UNITS_HANDLE = $_REQUEST['ADV_UNITS_HANDLE'];

    if (isset($_POST['insert'])) {
		$check = $mysqli->query("SELECT ADV_ID FROM hogwarts_enrollment_sys_fin_ver_3.ADVISER WHERE ADV_ID='$ADV_ID'");
		if ($check->num_rows > 0) {
			echo "Duplicate entry detected";
		} else {
			$sql = "INSERT INTO hogwarts_enrollment_sys_fin_ver_3.ADVISER(ADV_ID, ADV_NAME, ADV_HANDLED_SECTIONS, ADV_UNITS_HANDLE) VALUES ('$ADV_ID', '$ADV_NAME', '$ADV_HANDLED_SECTIONS', '$ADV_UNITS_HANDLE')";
			if (mysqli_query($mysqli, $sql)) {
				echo "Data inserted successfully!";
			} else {
				echo mysqli_error($mysqli);
			}
		}
    }

    if (isset($_POST['delete'])) {
        $check = $mysqli->query("SELECT ADV_ID FROM hogwarts_enrollment_sys_fin_ver_3.ADVISER WHERE ADV_ID='$ADV_ID'");
        if ($check->num_rows === 0) {
            echo "Record doesn't exist";
        } else {
            $sql = "DELETE FROM hogwarts_enrollment_sys_fin_ver_3.ADVISER WHERE ADV_ID='$ADV_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data deleted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['update'])) {
		$origin = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.ADVISER WHERE ADV_ID='$ADV_ID'";
		$result = $mysqli->query($origin);
		if ($result->num_rows == 0) {
			echo "Record doesn't exist";
		} else {
			$row = $result->fetch_assoc();

			if ($ADV_NAME !== "" and $ADV_NAME != $row['ADV_NAME']) {
				$ADV_NAME = $ADV_NAME;
			} else {
				$ADV_NAME = $row["ADV_NAME"];
			}
			if ($ADV_HANDLED_SECTIONS !== "" and $ADV_HANDLED_SECTIONS != $row['ADV_HANDLED_SECTIONS']) {
				$ADV_HANDLED_SECTIONS = $ADV_HANDLED_SECTIONS;
			} else {
				$ADV_HANDLED_SECTIONS = $row["ADV_HANDLED_SECTIONS"];
			}
			if ($ADV_UNITS_HANDLE !== "" and $ADV_UNITS_HANDLE != $row['ADV_UNITS_HANDLE']) {
				$ADV_UNITS_HANDLE = $ADV_UNITS_HANDLE;
			} else {
				$ADV_UNITS_HANDLE = $row["ADV_UNITS_HANDLE"];
			}
			$sql = "UPDATE hogwarts_enrollment_sys_fin_ver_3.ADVISER SET ADV_NAME = '$ADV_NAME', ADV_HANDLED_SECTIONS = '$ADV_HANDLED_SECTIONS', ADV_UNITS_HANDLE = '$ADV_UNITS_HANDLE' WHERE ADV_ID='$ADV_ID'";
			if (mysqli_query($mysqli, $sql)) {
				echo "Data updated successfully!";
			} else {
				echo mysqli_error($mysqli);
			}
		}
	}
    $mysqli->close();
?>

<html>
<head>
</head>
<body>
<form action="adviser.php" method="POST">
    <input type="submit" value="Return">
</form>
</body>
</html>
