<?php
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {  // check if can connect
        die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
    } else {
        echo "Successfully opened $database";
    }

    $sql = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.ADVISER";
    $result = $mysqli->query($sql);
    $mysqli->close();

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="adviser_design.css">
    <title>Hogwarts University Adviser Database</title>
</head>
<body>
<table>
    <tr>
        <th>Adviser ID</th>
        <th>Adviser Name</th>
        <th>Adviser Handled Sections</th>
        <th>Adviser Units Handle</th>
    </tr>
    <?php
    while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo "A-" . $row['ADV_ID'];?></td>
            <td><?php echo $row['ADV_NAME'];?></td>
            <td><?php echo $row['ADV_HANDLED_SECTIONS'];?></td>
            <td><?php echo $row['ADV_UNITS_HANDLE'];?></td>
        </tr>
        <?php
    }
    ?>
</table>
<br>
<form action="adviser_functions.php" method="POST">
    <label for="ADV_ID">Adviser ID:</label>
    <input type="number" name="ADV_ID" min="1" max="9999999999" step="1" required><br>

    <label for="ADV_NAME">Adviser Name:</label>
    <input type="text" name="ADV_NAME" required><br>

    <label for="ADV_HANDLED_SECTIONS">Adviser Handled Sections:</label>
    <input type="number" name="ADV_HANDLED_SECTIONS" min="1" max="99" required><br>

    <label for="ADV_UNITS_HANDLE">Adviser Units Handle:</label>
    <input type="number" name="ADV_UNITS_HANDLE" min="1" max="12" required><br>

    <div class="buttons">
        <input type="submit" name="insert" value="Insert">
        <input type="submit" name="update" value="Update">
        <input type="submit" name="delete" value="Delete">
        <button onclick="location.href='admin_main.php'">Return</button>
    </div>
</form>
</body>
</html>