<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {
        die('Connect Error(' . $mysqli->maxdb_connect_errorno() . ')' . $mysqli->maxdb_connect_error());
    }

    $PAY_INVOICE = $_REQUEST['FEE_INVOICE'];
    $PAY_DATE = $_REQUEST['PAY_DATE'];
    $PAY_AMOUNT = $_REQUEST['PAY_AMOUNT'];
    $FEE_INVOICE = $_REQUEST['FEE_INVOICE'];
    $METHOD_ID = $_REQUEST['METHOD_ID'];
	$PAY_OPTIONS = $_REQUEST['PAY_OPTIONS'];

    if (isset($_POST['insert'])) {
        $foreign_check = $mysqli->query("SELECT FEE_INVOICE FROM hogwarts_enrollment_sys_fin_ver_3.FEE WHERE FEE_INVOICE = '$FEE_INVOICE'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Fee invoice number does not exist";
            exit;
        }
		$foreign_check = $mysqli->query("SELECT METHOD_ID FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT_METHOD WHERE METHOD_ID = '$METHOD_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Payment method ID does not exist";
            exit;
        }
        $check = $mysqli->query("SELECT PAY_INVOICE FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT WHERE PAY_INVOICE='$PAY_INVOICE'");
        if ($check->num_rows > 0) {
            echo "Duplicate entry detected";
        } else {
            $sql = "INSERT INTO hogwarts_enrollment_sys_fin_ver_3.PAYMENT(PAY_INVOICE, PAY_DATE, PAY_AMOUNT, FEE_INVOICE, METHOD_ID, PAY_OPTIONS) VALUES ('$PAY_INVOICE', '$PAY_DATE', '$PAY_AMOUNT', '$FEE_INVOICE', '$METHOD_ID', '$PAY_OPTIONS')";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data inserted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['delete'])) {
        $check = $mysqli->query("SELECT PAY_INVOICE FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT WHERE PAY_INVOICE='$PAY_INVOICE'");
        if ($check->num_rows === 0) {
            echo "Record doesn't exist";
        } else {
            $sql = "DELETE FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT WHERE PAY_INVOICE='$PAY_INVOICE'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data deleted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['update'])) {
        $foreign_check = $mysqli->query("SELECT FEE_INVOICE FROM hogwarts_enrollment_sys_fin_ver_3.FEE WHERE FEE_INVOICE = '$FEE_INVOICE'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Fee invoice number does not exist";
            exit;
        }
		$foreign_check = $mysqli->query("SELECT METHOD_ID FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT_METHOD WHERE METHOD_ID = '$METHOD_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Payment method ID does not exist";
            exit;
        }
        $origin = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT WHERE PAY_INVOICE='$PAY_INVOICE'";
        $result = $mysqli->query($origin);
        if ($result->num_rows == 0) {
            echo "Record doesn't exist";
        } else {
            $row = $result->fetch_assoc();

            if ($PAY_DATE !== "" and $PAY_DATE != $row['PAY_DATE']) {
                $PAY_DATE = $PAY_DATE;
            } else {
                $PAY_DATE = $row["PAY_DATE"];
            }
            if ($PAY_AMOUNT !== "" and $PAY_AMOUNT != $row['PAY_AMOUNT']) {
                $PAY_AMOUNT = $PAY_AMOUNT;
            } else {
                $PAY_AMOUNT = $row["PAY_AMOUNT"];
            }
            if ($FEE_INVOICE !== "" and $FEE_INVOICE != $row['FEE_INVOICE']) {
                $FEE_INVOICE = $FEE_INVOICE;
            } else {
                $FEE_INVOICE = $row["FEE_INVOICE"];
            }
            if ($METHOD_ID !== "" and $METHOD_ID != $row['METHOD_ID']) {
                $METHOD_ID = $METHOD_ID;
            } else {
                $METHOD_ID = $row["METHOD_ID"];
            }
			if ($PAY_OPTIONS !== "" and $PAY_OPTIONS != $row['PAY_OPTIONS']) {
                $PAY_OPTIONS = $PAY_OPTIONS;
            } else {
                $PAY_OPTIONS = $row["PAY_OPTIONS"];
            }
            $sql = "UPDATE hogwarts_enrollment_sys_fin_ver_3.PAYMENT SET PAY_DATE = '$PAY_DATE', PAY_AMOUNT = '$PAY_AMOUNT', FEE_INVOICE = '$FEE_INVOICE', METHOD_ID = '$METHOD_ID', PAY_OPTIONS = '$PAY_OPTIONS' WHERE PAY_INVOICE='$PAY_INVOICE'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data updated successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }
    $mysqli->close();
?>

<html>
<head>
</head>
<body>
<form action="payment.php" method="POST">
    <input type="submit" value="Return">
</form>
</body>
</html>
