<?php
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {  // check if can connect
        die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
    } else {
        echo "Successfully opened $database";
    }

    $sql = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.PAYMENT";
    $result = $mysqli->query($sql);
    $mysqli->close();

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="payment_design.css">
    <title>Hogwarts University Adviser Database</title>
</head>
<body>
<table>
    <tr>
        <th>Payment Invoice</th>
		<th>Fee Invoice</th>
		<th>Method ID</th>
        <th>Payment Date</th>
        <th>Payment Amount</th>
		<th>Payment Options</th>
    </tr>
    <?php
    while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo "P-". $row['PAY_INVOICE'];?></td>
			<td><?php echo "FEE-" . $row['FEE_INVOICE'];?></td>
			<td><?php echo "PMD-" . $row['METHOD_ID'];?></td>
            <td><?php echo $row['PAY_DATE'];?></td>
            <td><?php echo $row['PAY_AMOUNT'];?></td>
			<td><?php echo $row['PAY_OPTIONS'];?></td>
        </tr>
        <?php
    }
    ?>
</table>
<br>
<form action="payment_functions.php" method="POST">
    <label for="PAY_INVOICE">Pay Invoice:</label>
    <input type="number" name="PAY_INVOICE" min="1" max="9999999999" step="1" required><br>

    <label for="FEE_INVOICE">Fee Invoice:</label>
    <input type="number" name="FEE_INVOICE" min="1" max="9999999999" step="1" required><br>
	
	<label for="METHOD_ID">Payment Method ID:</label>
    <input type="number" name="METHOD_ID" min="1" max="9999999999" step="1" required><br>

    <label for="PAY_DATE">Payment Date:</label>
    <input type="date" name="PAY_DATE" min="2025-01-01" max="2030-12-31" required><br>

    <label for="PAY_AMOUNT">Payment Amount:</label>
    <input type="number" name="PAY_AMOUNT" min="0.00" max="99999.99" step="0.01" required><br>
	
	<label for="PAY_OPTIONS">Payment Options:</label>
    <select name="PAY_OPTIONS" id="PAY_OPTIONS" required>
        <option value="None">None</option>
        <option value="Full payment">Full payment</option>
        <option value="Installment">Installment</option>
    </select><br>
	
    <div class="buttons">
        <input type="submit" name="insert" value="Insert">
        <input type="submit" name="update" value="Update">
        <input type="submit" name="delete" value="Delete">
        <button onclick="location.href='admin_main.php'">Return</button>
    </div>
</form>
</body>
</html>