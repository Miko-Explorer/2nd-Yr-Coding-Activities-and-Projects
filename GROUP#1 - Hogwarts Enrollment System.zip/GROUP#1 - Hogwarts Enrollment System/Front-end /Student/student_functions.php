<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    $user = 'root';
    $password = '!fKBL9Vmxxge';
    $database = 'hogwarts_enrollment_sys_fin_ver_3';
    $servername = 'localhost:3310';

    $mysqli = new mysqli($servername, $user, $password, $database);

    if ($mysqli->connect_errno) {
        die('Connect Error(' . $mysqli->maxdb_connect_errorno() . ')' . $mysqli->maxdb_connect_error());
    }

    $STUD_ID = $_REQUEST['STUD_ID'];
    $PROG_ID = $_REQUEST['PROG_ID'];
    $STUD_NAME = $_REQUEST['STUD_NAME'];
    $STUD_ADDRESS = $_REQUEST['STUD_ADDRESS'];
    $STUD_AGE = $_REQUEST['STUD_AGE'];
    $STUD_SCHOLARSHIP = $_REQUEST['STUD_SCHOLARSHIP'];

    if (isset($_POST['insert'])) {
        $foreign_check = $mysqli->query("SELECT PROG_ID FROM hogwarts_enrollment_sys_fin_ver_3.PROGRAM WHERE PROG_ID = '$PROG_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Program ID does not exist";
            exit;
        }
        $check = $mysqli->query("SELECT STUD_ID FROM hogwarts_enrollment_sys_fin_ver_3.STUDENT WHERE STUD_ID='$STUD_ID'");
        if ($check->num_rows > 0) {
            echo "Duplicate entry detected";
        } else {
            $sql = "INSERT INTO hogwarts_enrollment_sys_fin_ver_3.STUDENT(STUD_ID, PROG_ID, STUD_NAME, STUD_ADDRESS, STUD_AGE, STUD_SCHOLARSHIP) VALUES ('$STUD_ID', '$PROG_ID', '$STUD_NAME', '$STUD_ADDRESS', '$STUD_AGE', '$STUD_SCHOLARSHIP')";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data inserted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['delete'])) {
        $check = $mysqli->query("SELECT STUD_ID FROM hogwarts_enrollment_sys_fin_ver_3.STUDENT WHERE STUD_ID='$STUD_ID'");
        if ($check->num_rows === 0) {
            echo "Record doesn't exist";
        } else {
            $sql = "DELETE FROM hogwarts_enrollment_sys_fin_ver_3.STUDENT WHERE STUD_ID='$STUD_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data deleted successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }

    if (isset($_POST['update'])) {
        $foreign_check = $mysqli->query("SELECT PROG_ID FROM hogwarts_enrollment_sys_fin_ver_3.PROGRAM WHERE PROG_ID = '$PROG_ID'");
        if ($foreign_check->num_rows === 0) {
            echo "Foreign Key: Program ID does not exist";
            exit;
        }
        $origin = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.STUDENT WHERE STUD_ID='$STUD_ID'";
        $result = $mysqli->query($origin);
        if ($result->num_rows == 0) {
            echo "Record doesn't exist";
        } else {
            $row = $result->fetch_assoc();

            if ($PROG_ID !== "" and $PROG_ID != $row['PROG_ID']) {
                $PROG_ID = $PROG_ID;
            } else {
                $PROG_ID = $row["PROG_ID"];
            }
            if ($STUD_NAME !== "" and $STUD_NAME != $row['STUD_NAME']) {
                $STUD_NAME = $STUD_NAME;
            } else {
                $STUD_NAME = $row["STUD_NAME"];
            }
            if ($STUD_ADDRESS !== "" and $STUD_ADDRESS != $row['STUD_ADDRESS']) {
                $STUD_ADDRESS = $STUD_ADDRESS;
            } else {
                $STUD_ADDRESS = $row["STUD_ADDRESS"];
            }
            if ($STUD_AGE !== "" and $STUD_AGE != $row['STUD_AGE']) {
                $STUD_AGE = $STUD_AGE;
            } else {
                $STUD_AGE = $row["STUD_AGE"];
            }
            if ($STUD_SCHOLARSHIP !== "" and $STUD_SCHOLARSHIP != $row['STUD_SCHOLARSHIP']) {
                $STUD_SCHOLARSHIP = $STUD_SCHOLARSHIP;
            } else {
                $STUD_SCHOLARSHIP = $row["STUD_SCHOLARSHIP"];
            }
            $sql = "UPDATE hogwarts_enrollment_sys_fin_ver_3.STUDENT SET STUD_NAME = '$STUD_NAME', STUD_ADDRESS = '$STUD_ADDRESS', STUD_AGE = '$STUD_AGE', STUD_SCHOLARSHIP = '$STUD_SCHOLARSHIP' WHERE STUD_ID='$STUD_ID'";
            if (mysqli_query($mysqli, $sql)) {
                echo "Data updated successfully!";
            } else {
                echo mysqli_error($mysqli);
            }
        }
    }
    $mysqli->close();
?>

<html>
<head>
</head>
<body>
<form action="student.php" method="POST">
    <input type="submit" value="Return">
</form>
</body>
</html>
