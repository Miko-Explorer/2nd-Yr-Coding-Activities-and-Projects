<?php
$user = 'root';
$password = '!fKBL9Vmxxge';
$database = 'hogwarts_enrollment_sys_fin_ver_3';
$servername = 'localhost:3310';

$mysqli = new mysqli($servername, $user, $password, $database);

if ($mysqli->connect_errno) {  // check if can connect
    die('Connect Error('.$mysqli->maxdb_connect_errorno().')'.$mysqli->maxdb_connect_error());
} else {
    echo "Successfully opened $database";
}

$sql = "SELECT * FROM hogwarts_enrollment_sys_fin_ver_3.STUDENT";
$result = $mysqli->query($sql);
$mysqli->close();

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="student_design.css">
    <title>Hogwarts University Student Database</title>
</head>
<body>
<table>
    <tr>
        <th>Student ID</th>
		<th>Program ID</th>
        <th>Student Name</th>
        <th>Student Address</th>
        <th>Student Age</th>
        <th>Student Scholarship</th>	
    </tr>
    <?php
    while($row = $result->fetch_assoc()) {
        ?>
        <tr>
            <td><?php echo "S-" . $row['STUD_ID'];?></td>
			<td><?php echo "P-" . $row['PROG_ID'];?></td>
            <td><?php echo $row['STUD_NAME'];?></td>
            <td><?php echo $row['STUD_ADDRESS'];?></td>
            <td><?php echo $row['STUD_AGE'];?></td>
            <td><?php echo $row['STUD_SCHOLARSHIP'];?></td>
        </tr>
        <?php
    }
    ?>
</table>
<br>
<form action="student_functions.php" method="POST">
    <label for="STUD_ID">Student ID:</label>
    <input type="number" name="STUD_ID" min="1" max="9999999999" step="1" required><br>

    <label for="PROG_ID">Program ID:</label>
    <input type="number" name="PROG_ID" min="1" max="200" step="1" required><br>
	
	<label for="STUD_NAME">Student Name:</label>
    <input type="text" name="STUD_NAME" required><br>
	
	<label for="STUD_ADDRESS">Student Address:</label>
    <input type="text" name="STUD_ADDRESS" required><br>

    <label for="STUD_AGE">Student Age:</label>
    <input type="number" name="STUD_AGE" min="18" max="70" required><br>
	
	<label for="STUD_SCHOLARSHIP">Student Scholarship:</label>
    <select name="STUD_SCHOLARSHIP" id="STUD_SCHOLARSHIP" required>
        <option value="none">None</option>
        <option value="partial">Partial</option>
        <option value="full">Full</option>
    </select><br>    

    <div class="buttons">
        <input type="submit" name="insert" value="Insert">
        <input type="submit" name="update" value="Update">
        <input type="submit" name="delete" value="Delete">
        <button onclick="location.href='admin_main.php'">Return</button>
    </div>
</form>
</body>
</html>